
package projekt;
public class Score {
    private Student student;
    private Subject subject;
    private Criteria criteria;
    private int points;

    public Score(Student student, Subject subject, Criteria criteria, int points) {
        this.student = student;
        this.subject = subject;
        this.criteria = criteria;
        this.points = points;
    }

    @Override
    public String toString() {
        return student.getName() + " " + student.getSurname() +
               " | " + subject.getSubjectName() +
               " | " + criteria.name() +
               " | " + points + " pkt";
    }
}
